package com.example.smartnotes;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NotesFragment extends Fragment implements NotesAdapter.OnNoteListener {

    private RecyclerView recyclerView;
    private NotesAdapter notesAdapter;
    private DatabaseHelper databaseHelper;
    private FloatingActionButton fabAddNote;
    private EditText searchEditText;
    private TextView tvEmptyState;
    private List<Note> notesList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notes, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_notes);
        fabAddNote = view.findViewById(R.id.fab_add_note);
        searchEditText = view.findViewById(R.id.search_edit_text);
        tvEmptyState = view.findViewById(R.id.tv_empty_state);

        databaseHelper = new DatabaseHelper(getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        loadNotes();

        fabAddNote.setOnClickListener(v -> showAddNoteDialog());

        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchNotes(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        return view;
    }

    private void loadNotes() {
        notesList = databaseHelper.getAllNotes();
        updateUI(notesList, "Your notepad is empty.\nTap + to create your first note!");
    }

    private void searchNotes(String query) {
        if (query.isEmpty()) {
            loadNotes();
        } else {
            notesList = databaseHelper.searchNotes(query);
            updateUI(notesList, "No notes found matching '" + query + "'");
        }
    }

    private void updateUI(List<Note> list, String emptyMessage) {
        if (list.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvEmptyState.setVisibility(View.VISIBLE);
            tvEmptyState.setText(emptyMessage);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvEmptyState.setVisibility(View.GONE);
        }
        notesAdapter = new NotesAdapter(list, this);
        recyclerView.setAdapter(notesAdapter);
    }

    private void showAddNoteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_note, null);

       // EditText etTitle = dialogView.findViewById(R.id.et_note_title);
        EditText etTitle = dialogView.findViewById(R.id.edit_note_title);
        EditText etContent = dialogView.findViewById(R.id.edit_note_content);
        Spinner spinnerCategory = dialogView.findViewById(R.id.spinner_category);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.note_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        builder.setView(dialogView)
                .setTitle("Add New Note")
                .setPositiveButton("Save", (dialog, which) -> {
                    String title = etTitle.getText().toString().trim();
                    String content = etContent.getText().toString().trim();
                    String category = spinnerCategory.getSelectedItem().toString();

                    if (title.isEmpty() || content.isEmpty()) {
                        Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    String date = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date());
                    Note note = new Note(title, content, date, category);
                    databaseHelper.addNote(note);
                    loadNotes();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onNoteClick(int position) {
        showEditNoteDialog(notesList.get(position));
    }

    @Override
    public void onNoteLongClick(int position) {
        showDeleteConfirmation(notesList.get(position));
    }

    private void showEditNoteDialog(Note note) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_note, null);

        EditText etTitle = dialogView.findViewById(R.id.edit_note_title);
        EditText etContent = dialogView.findViewById(R.id.edit_note_content);
        Spinner spinnerCategory = dialogView.findViewById(R.id.spinner_category);

        etTitle.setText(note.getTitle());
        etContent.setText(note.getContent());

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.note_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);
        spinnerCategory.setSelection(adapter.getPosition(note.getCategory()));

        builder.setView(dialogView)
                .setTitle("Edit Note")
                .setPositiveButton("Update", (dialog, which) -> {
                    note.setTitle(etTitle.getText().toString().trim());
                    note.setContent(etContent.getText().toString().trim());
                    note.setCategory(spinnerCategory.getSelectedItem().toString());
                    databaseHelper.updateNote(note);
                    loadNotes();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showDeleteConfirmation(Note note) {
        new AlertDialog.Builder(getContext())
                .setTitle("Delete Note")
                .setMessage("Are you sure?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    databaseHelper.deleteNote(note.getId());
                    loadNotes();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}